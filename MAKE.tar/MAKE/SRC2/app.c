// my_source.c
#include <stdio.h>
#include <stdlib.h>
#include <app.h>

int main()
{
	printf("%d\n", MAX);
}