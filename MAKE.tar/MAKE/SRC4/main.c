// main.c
#include <stdio.h>
#include <foo.h>
#include <goo.h>

int main()
{
	foo();
	goo();
	return 0;
}