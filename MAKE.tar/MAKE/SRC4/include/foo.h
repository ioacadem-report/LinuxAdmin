// foo.h

#define FOO 100

void foo();