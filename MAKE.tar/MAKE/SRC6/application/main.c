#include <stdio.h>
#include <stdlib.h>
#include <mylib.h>

int main (int arg, char *argv[])
{
	foo();
	goo();
	return 0;
}
