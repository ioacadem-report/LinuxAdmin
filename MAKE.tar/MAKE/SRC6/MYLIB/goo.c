// goo.c
#include <stdio.h>
#include <mylib.h>

void goo()
{
	printf("goo\n");
}