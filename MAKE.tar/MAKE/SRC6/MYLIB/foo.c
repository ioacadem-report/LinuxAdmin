// foo.c
#include <stdio.h>
#include <mylib.h>

void foo()
{
	printf("foo\n");
}