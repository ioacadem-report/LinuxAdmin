// mylib.h

void foo();
void goo();